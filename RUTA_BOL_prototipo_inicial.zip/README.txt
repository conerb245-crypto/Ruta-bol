RUTA-BOL - prototipo inicial publicable

CONTENIDO
- app.py: interfaz web Streamlit, mapa Folium, Dijkstra y rutas alternativas.
- requirements.txt: dependencias.

EJECUTAR LOCALMENTE
1. Instalar Python.
2. Abrir una terminal en esta carpeta.
3. Ejecutar: pip install -r requirements.txt
4. Ejecutar: streamlit run app.py

PUBLICAR EN STREAMLIT COMMUNITY CLOUD
1. Subir app.py y requirements.txt a un repositorio de GitHub.
2. Entrar a https://share.streamlit.io/
3. Iniciar sesión y elegir el repositorio, rama y archivo app.py.
4. Pulsar Deploy.

IMPORTANTE
Los nodos, conexiones, líneas y tiempos son DEMOSTRATIVOS. No son rutas reales verificadas.
Los bloqueos se simulan mediante casillas; todavía no existe una fuente automática de incidentes reales.
Los inventarios de 299 registros de El Alto y 572 de La Paz requieren importar y validar sus fichas
completas y coordenadas antes de usarlos como red navegable.
